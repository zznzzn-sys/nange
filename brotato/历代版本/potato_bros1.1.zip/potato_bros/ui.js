// ui.js - 游戏UI系统

class UIManager {
    constructor(game) {
        this.game = game;
        this.uiElements = [];
        this.activeMenu = null;
        this.notifications = [];
        this.floatingTexts = [];
        this.activeBuffs = [];
        
        // UI状态
        this.showHealthBar = true;
        this.showMoney = true;
        this.showWaveInfo = true;
        this.showWeaponInfo = true;
        this.showSkillInfo = true;
        
        // 初始化UI元素
        this.initializeUI();
    }
    
    // 初始化UI元素
    initializeUI() {
        // 创建状态栏
        this.createStatusBar();
        
        // 创建武器栏
        this.createWeaponBar();
        
        // 创建技能栏
        this.createSkillBar();
        
        // 创建开始菜单
        this.createStartMenu();
        
        // 创建角色选择菜单
        this.createCharacterSelectMenu();
        
        // 创建商店菜单
        this.createShopMenu();
        
        // 创建升级菜单
        this.createUpgradeMenu();
        
        // 创建暂停菜单
        this.createPauseMenu();
        
        // 创建结束菜单
        this.createEndMenu();
        
        // 创建设置菜单
        this.createSettingsMenu();
    }
    
    // 创建状态栏
    createStatusBar() {
        const statusBar = {
            type: 'statusBar',
            draw: (ctx) => {
                const player = this.game.data.player;
                if (!player) return;
                
                const canvas = this.game.canvas;
                const barHeight = 40;
                
                // 绘制背景
                ctx.save();
                ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                ctx.fillRect(0, 0, canvas.width, barHeight);
                
                // 绘制生命值
                if (this.showHealthBar) {
                    const healthBarWidth = 200;
                    const healthBarHeight = 20;
                    const healthRatio = player.health / player.maxHealth;
                    
                    // 健康颜色渐变
                    let healthColor = '#4caf50'; // 绿色
                    if (healthRatio < 0.3) healthColor = '#f44336'; // 红色
                    else if (healthRatio < 0.6) healthColor = '#ff9800'; // 橙色
                    
                    // 绘制生命值背景
                    ctx.fillStyle = '#333';
                    ctx.fillRect(20, 10, healthBarWidth, healthBarHeight);
                    
                    // 绘制生命值
                    ctx.fillStyle = healthColor;
                    ctx.fillRect(20, 10, healthBarWidth * healthRatio, healthBarHeight);
                    
                    // 绘制生命值文本
                    ctx.fillStyle = '#fff';
                    ctx.font = '16px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(`${Math.floor(player.health)}/${player.maxHealth}`, 
                        20 + healthBarWidth / 2, 24);
                }
                
                // 绘制金钱
                if (this.showMoney) {
                    ctx.fillStyle = '#ffd700';
                    ctx.font = 'bold 20px Arial';
                    ctx.textAlign = 'left';
                    ctx.fillText('$' + this.game.data.money, 250, 27);
                }
                
                // 绘制波数信息
                if (this.showWaveInfo) {
                    ctx.fillStyle = '#fff';
                    ctx.font = '16px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(`第 ${this.game.data.currentWave} 波 / 共 ${this.game.data.maxWaves} 波`, 
                        canvas.width / 2, 27);
                }
                
                // 绘制时间
                const timeLeft = Math.max(0, this.game.data.waveTime - this.game.data.waveTimer);
                ctx.fillStyle = '#fff';
                ctx.font = '16px Arial';
                ctx.textAlign = 'right';
                ctx.fillText(`剩余时间: ${Math.ceil(timeLeft)}s`, canvas.width - 20, 27);
                
                ctx.restore();
            }
        };
        
        this.uiElements.push(statusBar);
    }
    
    // 创建武器栏
    createWeaponBar() {
        const weaponBar = {
            type: 'weaponBar',
            draw: (ctx) => {
                if (!this.showWeaponInfo) return;
                
                const player = this.game.data.player;
                if (!player) return;
                
                const canvas = this.game.canvas;
                const barHeight = 60;
                const barWidth = 400;
                const x = (canvas.width - barWidth) / 2;
                const y = canvas.height - barHeight - 10;
                
                // 绘制背景
                ctx.save();
                ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                ctx.fillRect(x, y, barWidth, barHeight);
                
                // 获取武器信息
                const weaponInfo = player.getWeaponDisplayInfo();
                
                // 绘制武器槽
                const slotWidth = (barWidth - 40) / 3;
                const slotHeight = barHeight - 20;
                
                for (let i = 0; i < 3; i++) {
                    const slotX = x + 20 + i * (slotWidth + 10);
                    const slotY = y + 10;
                    
                    // 绘制武器槽背景
                    ctx.fillStyle = weaponInfo[i].isActive ? 'rgba(255, 255, 255, 0.2)' : 'rgba(255, 255, 255, 0.1)';
                    ctx.fillRect(slotX, slotY, slotWidth, slotHeight);
                    
                    // 绘制武器槽边框
                    ctx.strokeStyle = weaponInfo[i].isActive ? '#ff9800' : '#555';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(slotX, slotY, slotWidth, slotHeight);
                    
                    // 绘制武器名称
                    ctx.fillStyle = '#fff';
                    ctx.font = '12px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(`[${i+1}] ${weaponInfo[i].name}`, slotX + slotWidth / 2, slotY + 15);
                    
                    // 绘制弹药信息
                    if (weaponInfo[i].maxAmmo !== Infinity) {
                        ctx.fillStyle = weaponInfo[i].ammo > 0 ? '#4caf50' : '#f44336';
                        ctx.font = '12px Arial';
                        ctx.fillText(`${weaponInfo[i].ammo}/${weaponInfo[i].maxAmmo}`, 
                            slotX + slotWidth / 2, slotY + 35);
                    } else {
                        ctx.fillStyle = '#4caf50';
                        ctx.font = '12px Arial';
                        ctx.fillText('无限', slotX + slotWidth / 2, slotY + 35);
                    }
                }
                
                ctx.restore();
            }
        };
        
        this.uiElements.push(weaponBar);
    }
    
    // 创建技能栏
    createSkillBar() {
        const skillBar = {
            type: 'skillBar',
            draw: (ctx) => {
                if (!this.showSkillInfo) return;
                
                const player = this.game.data.player;
                if (!player || !player.skills) return;
                
                const canvas = this.game.canvas;
                const barHeight = 80;
                const skillSize = 60;
                
                // 绘制技能
                for (let i = 0; i < player.skills.length; i++) {
                    const skill = player.skills[i];
                    const x = canvas.width - 20 - skillSize - (skillSize + 10) * i;
                    const y = canvas.height - barHeight;
                    
                    ctx.save();
                    
                    // 绘制技能背景
                    ctx.fillStyle = skill.canUse() ? 'rgba(76, 175, 80, 0.2)' : 'rgba(244, 67, 54, 0.2)';
                    ctx.fillRect(x, y, skillSize, skillSize);
                    
                    // 绘制技能边框
                    ctx.strokeStyle = skill.canUse() ? '#4caf50' : '#f44336';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(x, y, skillSize, skillSize);
                    
                    // 绘制冷却时间覆盖
                    if (!skill.canUse()) {
                        const cooldownPercent = skill.getCooldownPercent();
                        const cooldownHeight = skillSize * (cooldownPercent / 100);
                        
                        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
                        ctx.fillRect(x, y, skillSize, cooldownHeight);
                        
                        // 绘制冷却时间文本
                        ctx.fillStyle = '#fff';
                        ctx.font = 'bold 14px Arial';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText(`${Math.ceil(skill.currentCooldown)}`, 
                            x + skillSize / 2, y + skillSize / 2);
                    }
                    
                    // 绘制技能图标
                    ctx.fillStyle = '#fff';
                    ctx.font = '24px Arial';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    
                    // 根据技能类型使用不同图标
                    let icon = '?';
                    switch (skill.name.toLowerCase()) {
                        case '土豆护盾': icon = '🛡️'; break;
                        case '土豆炸弹': icon = '💣'; break;
                    }
                    
                    ctx.fillText(icon, x + skillSize / 2, y + skillSize / 2 - 5);
                    
                    // 绘制技能快捷键
                    ctx.fillStyle = '#fff';
                    ctx.font = '12px Arial';
                    ctx.textAlign = 'left';
                    ctx.textBaseline = 'top';
                    ctx.fillText(`[${i+1}]`, x + 5, y + 5);
                    
                    ctx.restore();
                }
            }
        };
        
        this.uiElements.push(skillBar);
    }
    
    // 创建开始菜单
    createStartMenu() {
        this.startMenu = {
            type: 'menu',
            name: 'startMenu',
            visible: true,
            draw: (ctx) => {
                const canvas = this.game.canvas;
                const menuWidth = 400;
                const menuHeight = 500;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#ff9800';
                ctx.font = 'bold 48px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('土豆兄弟', x + menuWidth / 2, y + 80);
                
                // 绘制版本号
                ctx.fillStyle = '#666';
                ctx.font = '14px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('v1.0.0', x + menuWidth / 2, y + 120);
                
                // 绘制菜单项
                const buttons = [
                    { text: '开始游戏', y: 180, action: () => this.showMenu('characterSelectMenu') },
                    { text: '设置', y: 250, action: () => this.showMenu('settingsMenu') },
                    { text: '关于', y: 320, action: () => this.showAbout() },
                    { text: '退出', y: 390, action: () => window.close() }
                ];
                
                buttons.forEach(button => {
                    // 检查鼠标是否悬停
                    const buttonWidth = 250;
                    const buttonHeight = 50;
                    const buttonX = x + (menuWidth - buttonWidth) / 2;
                    const buttonY = y + button.y;
                    
                    const isHovered = this.isMouseInRect(
                        buttonX, buttonY, buttonWidth, buttonHeight
                    );
                    
                    // 绘制按钮背景
                    ctx.fillStyle = isHovered ? '#ff9800' : '#333';
                    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮边框
                    ctx.strokeStyle = isHovered ? '#ffc107' : '#555';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮文本
                    ctx.fillStyle = '#fff';
                    ctx.font = 'bold 20px Arial';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(button.text, buttonX + buttonWidth / 2, buttonY + buttonHeight / 2);
                    
                    // 存储按钮信息用于点击检测
                    button.rect = { x: buttonX, y: buttonY, width: buttonWidth, height: buttonHeight };
                });
                
                this.startMenu.buttons = buttons;
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.startMenu.visible || !this.startMenu.buttons) return;
                
                for (const button of this.startMenu.buttons) {
                    if (this.isMouseInRect(x, y, button.rect.width, button.rect.height, button.rect.x, button.rect.y)) {
                        button.action();
                        break;
                    }
                }
            }
        };
        
        this.uiElements.push(this.startMenu);
    }
    
    // 创建角色选择菜单
    createCharacterSelectMenu() {
        this.characterSelectMenu = {
            type: 'menu',
            name: 'characterSelectMenu',
            visible: false,
            draw: (ctx) => {
                const canvas = this.game.canvas;
                const menuWidth = 500;
                const menuHeight = 600;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#ff9800';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('选择角色', x + menuWidth / 2, y + 50);
                
                // 角色列表
                const characters = [
                    {
                        name: '普通土豆',
                        type: 'potato',
                        description: '属性均衡的普通土豆',
                        stats: '生命值: 100\n伤害: 10\n速度: 100\n幸运: 100',
                        special: '无特殊能力，但属性均衡'
                    },
                    {
                        name: '强壮土豆',
                        type: 'strong',
                        description: '高生命值和防御力的土豆',
                        stats: '生命值: 150\n伤害: 12\n速度: 70\n幸运: 80',
                        special: '受到伤害减少10%'
                    },
                    {
                        name: '敏捷土豆',
                        type: 'fast',
                        description: '高速度和闪避能力的土豆',
                        stats: '生命值: 80\n伤害: 9\n速度: 150\n幸运: 120',
                        special: '移动时闪避率提高15%'
                    }
                ];
                
                // 绘制角色选项
                const characterHeight = 140;
                
                characters.forEach((character, index) => {
                    const charY = y + 100 + index * (characterHeight + 20);
                    const isHovered = this.isMouseInRect(
                        x + 20, charY, menuWidth - 40, characterHeight
                    );
                    
                    // 绘制角色框
                    ctx.fillStyle = isHovered ? 'rgba(255, 152, 0, 0.2)' : 'rgba(255, 255, 255, 0.05)';
                    ctx.fillRect(x + 20, charY, menuWidth - 40, characterHeight);
                    
                    // 绘制角色边框
                    ctx.strokeStyle = isHovered ? '#ff9800' : '#333';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(x + 20, charY, menuWidth - 40, characterHeight);
                    
                    // 绘制角色名称
                    ctx.fillStyle = '#ff9800';
                    ctx.font = 'bold 24px Arial';
                    ctx.textAlign = 'left';
                    ctx.fillText(character.name, x + 40, charY + 35);
                    
                    // 绘制角色描述
                    ctx.fillStyle = '#ccc';
                    ctx.font = '16px Arial';
                    ctx.fillText(character.description, x + 40, charY + 60);
                    
                    // 绘制角色属性
                    ctx.fillStyle = '#999';
                    ctx.font = '14px Arial';
                    const stats = character.stats.split('\n');
                    stats.forEach((stat, i) => {
                        ctx.fillText(stat, x + 40, charY + 85 + i * 20);
                    });
                    
                    // 绘制特殊能力
                    ctx.fillStyle = '#4caf50';
                    ctx.font = '14px Arial';
                    ctx.textAlign = 'right';
                    ctx.fillText(`特殊: ${character.special}`, x + menuWidth - 40, charY + 35);
                    
                    // 存储角色信息用于点击检测
                    character.rect = { x: x + 20, y: charY, width: menuWidth - 40, height: characterHeight };
                });
                
                this.characterSelectMenu.characters = characters;
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.characterSelectMenu.visible || !this.characterSelectMenu.characters) return;
                
                for (const character of this.characterSelectMenu.characters) {
                    if (this.isMouseInRect(x, y, character.rect.width, character.rect.height, character.rect.x, character.rect.y)) {
                        // 开始游戏，选择角色
                        this.hideAllMenus();
                        this.game.startGame(character.type);
                        break;
                    }
                }
            }
        };
        
        this.uiElements.push(this.characterSelectMenu);
    }
    
    // 创建商店菜单
    createShopMenu() {
        this.shopMenu = {
            type: 'menu',
            name: 'shopMenu',
            visible: false,
            shopItems: [],
            draw: (ctx) => {
                if (!this.shopMenu.visible) return;
                
                const canvas = this.game.canvas;
                const menuWidth = 800;
                const menuHeight = 600;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#ff9800';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('商店', x + menuWidth / 2, y + 50);
                
                // 绘制金钱
                ctx.fillStyle = '#ffd700';
                ctx.font = 'bold 24px Arial';
                ctx.textAlign = 'left';
                ctx.fillText(`金钱: $${this.game.data.money}`, x + 40, y + 45);
                
                // 绘制下一波提示
                ctx.fillStyle = '#ff9800';
                ctx.font = '20px Arial';
                ctx.textAlign = 'right';
                ctx.fillText(`下一波: ${this.game.data.currentWave + 1}`, x + menuWidth - 40, y + 45);
                
                // 绘制商品网格
                const itemWidth = (menuWidth - 100) / 2;
                const itemHeight = 150;
                
                for (let i = 0; i < this.shopMenu.shopItems.length; i++) {
                    const item = this.shopMenu.shopItems[i];
                    const row = Math.floor(i / 2);
                    const col = i % 2;
                    const itemX = x + 40 + col * (itemWidth + 20);
                    const itemY = y + 100 + row * (itemHeight + 20);
                    
                    const canAfford = this.game.data.money >= item.price;
                    const isHovered = this.isMouseInRect(itemX, itemY, itemWidth, itemHeight);
                    
                    // 绘制商品背景
                    ctx.fillStyle = isHovered ? 'rgba(255, 152, 0, 0.2)' : 'rgba(255, 255, 255, 0.05)';
                    ctx.fillRect(itemX, itemY, itemWidth, itemHeight);
                    
                    // 绘制商品边框
                    ctx.strokeStyle = canAfford ? '#4caf50' : '#f44336';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(itemX, itemY, itemWidth, itemHeight);
                    
                    // 绘制商品名称
                    ctx.fillStyle = '#fff';
                    ctx.font = 'bold 20px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(item.item.name || item.name, itemX + itemWidth / 2, itemY + 35);
                    
                    // 绘制商品描述
                    ctx.fillStyle = '#ccc';
                    ctx.font = '14px Arial';
                    ctx.fillText(item.description, itemX + itemWidth / 2, itemY + 60);
                    
                    // 绘制价格
                    ctx.fillStyle = canAfford ? '#4caf50' : '#f44336';
                    ctx.font = 'bold 24px Arial';
                    ctx.fillText(`$${item.price}`, itemX + itemWidth / 2, itemY + 100);
                    
                    // 绘制购买按钮
                    const buttonWidth = 100;
                    const buttonHeight = 30;
                    const buttonX = itemX + (itemWidth - buttonWidth) / 2;
                    const buttonY = itemY + 115;
                    
                    ctx.fillStyle = canAfford ? (isHovered ? '#45a049' : '#4caf50') : '#555';
                    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    ctx.strokeStyle = canAfford ? '#388e3c' : '#666';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    ctx.fillStyle = '#fff';
                    ctx.font = '14px Arial';
                    ctx.fillText('购买', buttonX + buttonWidth / 2, buttonY + buttonHeight / 2 + 5);
                    
                    // 存储商品信息用于点击检测
                    item.rect = { x: itemX, y: itemY, width: itemWidth, height: itemHeight };
                }
                
                // 绘制继续按钮
                const continueButtonWidth = 150;
                const continueButtonHeight = 40;
                const continueButtonX = x + (menuWidth - continueButtonWidth) / 2;
                const continueButtonY = y + menuHeight - 60;
                const continueHovered = this.isMouseInRect(
                    continueButtonX, continueButtonY, continueButtonWidth, continueButtonHeight
                );
                
                ctx.fillStyle = continueHovered ? '#ff9800' : '#333';
                ctx.fillRect(continueButtonX, continueButtonY, continueButtonWidth, continueButtonHeight);
                
                ctx.strokeStyle = continueHovered ? '#ffc107' : '#555';
                ctx.lineWidth = 2;
                ctx.strokeRect(continueButtonX, continueButtonY, continueButtonWidth, continueButtonHeight);
                
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 18px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('继续游戏', continueButtonX + continueButtonWidth / 2, continueButtonY + continueButtonHeight / 2);
                
                this.shopMenu.continueButton = {
                    x: continueButtonX,
                    y: continueButtonY,
                    width: continueButtonWidth,
                    height: continueButtonHeight
                };
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.shopMenu.visible) return;
                
                // 检查是否点击继续按钮
                const continueButton = this.shopMenu.continueButton;
                if (continueButton && this.isMouseInRect(
                    x, y, continueButton.width, continueButton.height, continueButton.x, continueButton.y
                )) {
                    this.hideMenu('shopMenu');
                    this.game.resumeGame();
                    return;
                }
                
                // 检查是否点击商品
                for (const item of this.shopMenu.shopItems) {
                    if (this.isMouseInRect(x, y, item.rect.width, item.rect.height, item.rect.x, item.rect.y)) {
                        // 检查是否有钱购买
                        if (this.game.data.money >= item.price) {
                            // 购买物品
                            this.game.data.money -= item.price;
                            
                            // 应用物品效果
                            if (item.type === 'weapon') {
                                this.game.data.player.addWeapon(item.item);
                                this.addNotification(`获得 ${item.item.name}`);
                            } else if (item.item.collect) {
                                // 直接收集物品
                                item.item.x = this.game.data.player.x;
                                item.item.y = this.game.data.player.y;
                                item.item.collect(this.game);
                            }
                            
                            // 重新生成商店物品
                            this.generateShopItems();
                        }
                        break;
                    }
                }
            },
            generateShopItems: function() {
                // 使用掉落管理器生成商店物品
                this.shopItems = globalDropManager.generateShopItems(this.game.data.level);
            }
        };
        
        this.uiElements.push(this.shopMenu);
    }
    
    // 创建升级菜单
    createUpgradeMenu() {
        this.upgradeMenu = {
            type: 'menu',
            name: 'upgradeMenu',
            visible: false,
            upgradeOptions: [],
            draw: (ctx) => {
                if (!this.upgradeMenu.visible) return;
                
                const canvas = this.game.canvas;
                const menuWidth = 800;
                const menuHeight = 600;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#9c27b0';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#9c27b0';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('选择升级', x + menuWidth / 2, y + 50);
                
                // 绘制等级信息
                ctx.fillStyle = '#fff';
                ctx.font = '20px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(`等级 ${this.game.data.level}`, x + menuWidth / 2, y + 90);
                
                // 绘制升级选项
                const optionHeight = 120;
                const optionCount = Math.min(3, this.upgradeMenu.upgradeOptions.length);
                
                for (let i = 0; i < optionCount; i++) {
                    const option = this.upgradeMenu.upgradeOptions[i];
                    const optionY = y + 130 + i * (optionHeight + 20);
                    const isHovered = this.isMouseInRect(
                        x + 40, optionY, menuWidth - 80, optionHeight
                    );
                    
                    // 绘制选项背景
                    ctx.fillStyle = isHovered ? 'rgba(156, 39, 176, 0.2)' : 'rgba(255, 255, 255, 0.05)';
                    ctx.fillRect(x + 40, optionY, menuWidth - 80, optionHeight);
                    
                    // 绘制选项边框
                    ctx.strokeStyle = '#9c27b0';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(x + 40, optionY, menuWidth - 80, optionHeight);
                    
                    // 绘制选项名称
                    ctx.fillStyle = '#9c27b0';
                    ctx.font = 'bold 24px Arial';
                    ctx.textAlign = 'left';
                    ctx.fillText(option.name, x + 60, optionY + 35);
                    
                    // 绘制选项描述
                    ctx.fillStyle = '#ccc';
                    ctx.font = '16px Arial';
                    ctx.fillText(option.description, x + 60, optionY + 65);
                    
                    // 绘制选项效果
                    ctx.fillStyle = '#4caf50';
                    ctx.font = '14px Arial';
                    ctx.fillText(option.effect, x + 60, optionY + 90);
                    
                    // 存储选项信息用于点击检测
                    option.rect = { x: x + 40, y: optionY, width: menuWidth - 80, height: optionHeight };
                }
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.upgradeMenu.visible) return;
                
                // 检查是否点击升级选项
                for (const option of this.upgradeMenu.upgradeOptions) {
                    if (this.isMouseInRect(x, y, option.rect.width, option.rect.height, option.rect.x, option.rect.y)) {
                        // 应用升级
                        option.apply(this.game);
                        
                        // 隐藏升级菜单
                        this.hideMenu('upgradeMenu');
                        this.game.resumeGame();
                        break;
                    }
                }
            },
            generateUpgradeOptions: function() {
                // 生成升级选项
                const upgradePool = [
                    {
                        name: '生命值提升',
                        description: '增加最大生命值',
                        effect: '+30 最大生命值',
                        apply: (game) => {
                            game.data.player.increaseMaxHealth(30);
                            game.addNotification('最大生命值 +30');
                        }
                    },
                    {
                        name: '伤害提升',
                        description: '增加所有武器伤害',
                        effect: '+10% 伤害',
                        apply: (game) => {
                            game.data.player.damageMultiplier = (game.data.player.damageMultiplier || 1) * 1.1;
                            game.addNotification('伤害 +10%');
                        }
                    },
                    {
                        name: '速度提升',
                        description: '增加移动速度',
                        effect: '+20 移动速度',
                        apply: (game) => {
                            game.data.player.increaseSpeed(20);
                            game.addNotification('移动速度 +20');
                        }
                    },
                    {
                        name: '幸运提升',
                        description: '增加暴击率和掉落率',
                        effect: '+30 幸运值',
                        apply: (game) => {
                            game.data.player.increaseLuck(30);
                            game.addNotification('幸运值 +30');
                        }
                    },
                    {
                        name: '防御提升',
                        description: '减少受到的伤害',
                        effect: '+15% 伤害减免',
                        apply: (game) => {
                            if (!game.data.player.damageReduction) game.data.player.damageReduction = 0;
                            game.data.player.damageReduction += 0.15;
                            game.addNotification('伤害减免 +15%');
                        }
                    },
                    {
                        name: '技能冷却减少',
                        description: '减少所有技能冷却时间',
                        effect: '-20% 冷却时间',
                        apply: (game) => {
                            if (!game.data.player.skillCooldownMultiplier) game.data.player.skillCooldownMultiplier = 1;
                            game.data.player.skillCooldownMultiplier *= 0.8;
                            game.addNotification('技能冷却 -20%');
                        }
                    },
                    {
                        name: '弹药容量提升',
                        description: '增加所有武器的弹药容量',
                        effect: '+30% 弹药容量',
                        apply: (game) => {
                            game.data.player.ammoMultiplier = (game.data.player.ammoMultiplier || 1) * 1.3;
                            // 立即更新所有武器的弹药
                            for (const weapon of game.data.player.weapons) {
                                weapon.maxAmmo = Math.floor(weapon.maxAmmo * 1.3);
                                weapon.ammo = weapon.maxAmmo;
                            }
                            game.addNotification('弹药容量 +30%');
                        }
                    },
                    {
                        name: '投射物速度提升',
                        description: '增加所有投射物的飞行速度',
                        effect: '+25% 投射物速度',
                        apply: (game) => {
                            game.data.player.projectileSpeedMultiplier = (game.data.player.projectileSpeedMultiplier || 1) * 1.25;
                            game.addNotification('投射物速度 +25%');
                        }
                    }
                ];
                
                // 随机选择3个选项
                const selectedOptions = [];
                const shuffled = [...upgradePool].sort(() => 0.5 - Math.random());
                
                for (let i = 0; i < 3 && i < shuffled.length; i++) {
                    selectedOptions.push(shuffled[i]);
                }
                
                this.upgradeOptions = selectedOptions;
            }
        };
        
        this.uiElements.push(this.upgradeMenu);
    }
    
    // 创建暂停菜单
    createPauseMenu() {
        this.pauseMenu = {
            type: 'menu',
            name: 'pauseMenu',
            visible: false,
            draw: (ctx) => {
                if (!this.pauseMenu.visible) return;
                
                const canvas = this.game.canvas;
                const menuWidth = 400;
                const menuHeight = 400;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#ff9800';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('游戏暂停', x + menuWidth / 2, y + 70);
                
                // 绘制菜单项
                const buttons = [
                    { text: '继续游戏', y: 120, action: () => {
                        this.hideMenu('pauseMenu');
                        this.game.resumeGame();
                    }},
                    { text: '设置', y: 190, action: () => this.showMenu('settingsMenu') },
                    { text: '返回主菜单', y: 260, action: () => {
                        this.hideAllMenus();
                        this.showMenu('startMenu');
                        this.game.resetGame();
                    }},
                    { text: '退出游戏', y: 330, action: () => window.close() }
                ];
                
                // 调整按钮位置
                buttons.forEach((button, index) => {
                    if (index === 0) button.y = 120;
                    else if (index === 1) button.y = 180;
                    else if (index === 2) button.y = 240;
                    else if (index === 3) button.y = 300;
                });
                
                buttons.forEach(button => {
                    // 检查鼠标是否悬停
                    const buttonWidth = 250;
                    const buttonHeight = 50;
                    const buttonX = x + (menuWidth - buttonWidth) / 2;
                    const buttonY = y + button.y;
                    
                    const isHovered = this.isMouseInRect(
                        buttonX, buttonY, buttonWidth, buttonHeight
                    );
                    
                    // 绘制按钮背景
                    ctx.fillStyle = isHovered ? '#ff9800' : '#333';
                    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮边框
                    ctx.strokeStyle = isHovered ? '#ffc107' : '#555';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮文本
                    ctx.fillStyle = '#fff';
                    ctx.font = 'bold 20px Arial';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(button.text, buttonX + buttonWidth / 2, buttonY + buttonHeight / 2);
                    
                    // 存储按钮信息用于点击检测
                    button.rect = { x: buttonX, y: buttonY, width: buttonWidth, height: buttonHeight };
                });
                
                this.pauseMenu.buttons = buttons;
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.pauseMenu.visible || !this.pauseMenu.buttons) return;
                
                for (const button of this.pauseMenu.buttons) {
                    if (this.isMouseInRect(x, y, button.rect.width, button.rect.height, button.rect.x, button.rect.y)) {
                        button.action();
                        break;
                    }
                }
            }
        };
        
        this.uiElements.push(this.pauseMenu);
    }
    
    // 创建结束菜单
    createEndMenu() {
        this.endMenu = {
            type: 'menu',
            name: 'endMenu',
            visible: false,
            isVictory: false,
            stats: {},
            draw: (ctx) => {
                if (!this.endMenu.visible) return;
                
                const canvas = this.game.canvas;
                const menuWidth = 600;
                const menuHeight = 500;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = this.endMenu.isVictory ? '#4caf50' : '#f44336';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = this.endMenu.isVictory ? '#4caf50' : '#f44336';
                ctx.font = 'bold 48px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(this.endMenu.isVictory ? '胜利！' : '失败！', x + menuWidth / 2, y + 80);
                
                // 绘制统计信息
                ctx.fillStyle = '#fff';
                ctx.font = '18px Arial';
                ctx.textAlign = 'left';
                
                const stats = [
                    `到达波数: ${this.endMenu.stats.currentWave || 0}`,
                    `击杀敌人: ${this.endMenu.stats.enemiesKilled || 0}`,
                    `造成伤害: ${this.endMenu.stats.damageDealt || 0}`,
                    `收集金钱: ${this.endMenu.stats.moneyCollected || 0}`,
                    `收集物品: ${this.endMenu.stats.itemsCollected || 0}`,
                    `最高连击: ${this.endMenu.stats.highestCombo || 0}`,
                    `游戏时间: ${Math.floor((this.endMenu.stats.timePlayed || 0) / 60)}:${Math.floor((this.endMenu.stats.timePlayed || 0) % 60).toString().padStart(2, '0')}`
                ];
                
                stats.forEach((stat, index) => {
                    ctx.fillText(stat, x + 100, y + 140 + index * 30);
                });
                
                // 绘制按钮
                const buttons = [
                    { text: '再玩一次', y: 380, action: () => {
                        this.hideMenu('endMenu');
                        this.showMenu('characterSelectMenu');
                    }},
                    { text: '返回主菜单', y: 450, action: () => {
                        this.hideAllMenus();
                        this.showMenu('startMenu');
                    }}
                ];
                
                buttons.forEach(button => {
                    // 检查鼠标是否悬停
                    const buttonWidth = 200;
                    const buttonHeight = 40;
                    const buttonX = x + (menuWidth - buttonWidth) / 2;
                    const buttonY = y + button.y;
                    
                    const isHovered = this.isMouseInRect(
                        buttonX, buttonY, buttonWidth, buttonHeight
                    );
                    
                    // 绘制按钮背景
                    ctx.fillStyle = isHovered ? (this.endMenu.isVictory ? '#4caf50' : '#f44336') : '#333';
                    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮边框
                    ctx.strokeStyle = isHovered ? (this.endMenu.isVictory ? '#45a049' : '#d32f2f') : '#555';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(buttonX, buttonY, buttonWidth, buttonHeight);
                    
                    // 绘制按钮文本
                    ctx.fillStyle = '#fff';
                    ctx.font = 'bold 18px Arial';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(button.text, buttonX + buttonWidth / 2, buttonY + buttonHeight / 2);
                    
                    // 存储按钮信息用于点击检测
                    button.rect = { x: buttonX, y: buttonY, width: buttonWidth, height: buttonHeight };
                });
                
                this.endMenu.buttons = buttons;
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.endMenu.visible || !this.endMenu.buttons) return;
                
                for (const button of this.endMenu.buttons) {
                    if (this.isMouseInRect(x, y, button.rect.width, button.rect.height, button.rect.x, button.rect.y)) {
                        button.action();
                        break;
                    }
                }
            }
        };
        
        this.uiElements.push(this.endMenu);
    }
    
    // 创建设置菜单
    createSettingsMenu() {
        this.settingsMenu = {
            type: 'menu',
            name: 'settingsMenu',
            visible: false,
            draw: (ctx) => {
                if (!this.settingsMenu.visible) return;
                
                const canvas = this.game.canvas;
                const menuWidth = 500;
                const menuHeight = 450;
                const x = (canvas.width - menuWidth) / 2;
                const y = (canvas.height - menuHeight) / 2;
                
                ctx.save();
                
                // 绘制半透明背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // 绘制菜单背景
                ctx.fillStyle = '#1a1a1a';
                ctx.fillRect(x, y, menuWidth, menuHeight);
                
                // 绘制菜单边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, menuWidth, menuHeight);
                
                // 绘制标题
                ctx.fillStyle = '#ff9800';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('设置', x + menuWidth / 2, y + 50);
                
                // 绘制设置项
                const settings = [
                    { name: '音量', type: 'slider', value: 80 },
                    { name: '音乐', type: 'toggle', value: true },
                    { name: '音效', type: 'toggle', value: true },
                    { name: '自动拾取', type: 'toggle', value: true },
                    { name: '显示伤害', type: 'toggle', value: true }
                ];
                
                settings.forEach((setting, index) => {
                    const settingY = y + 100 + index * 60;
                    
                    // 绘制设置名称
                    ctx.fillStyle = '#fff';
                    ctx.font = '20px Arial';
                    ctx.textAlign = 'left';
                    ctx.fillText(setting.name, x + 60, settingY + 20);
                    
                    // 根据设置类型绘制控件
                    if (setting.type === 'toggle') {
                        const toggleWidth = 60;
                        const toggleHeight = 30;
                        const toggleX = x + menuWidth - 120;
                        const toggleY = settingY + 5;
                        
                        const isHovered = this.isMouseInRect(toggleX, toggleY, toggleWidth, toggleHeight);
                        
                        // 绘制开关背景
                        ctx.fillStyle = setting.value ? '#4caf50' : '#757575';
                        ctx.fillRect(toggleX, toggleY, toggleWidth, toggleHeight);
                        
                        // 绘制开关滑块
                        const sliderX = setting.value ? toggleX + toggleWidth - toggleHeight + 2 : toggleX + 2;
                        
                        ctx.fillStyle = '#fff';
                        ctx.fillRect(sliderX, toggleY + 2, toggleHeight - 4, toggleHeight - 4);
                        
                        // 存储开关信息用于点击检测
                        setting.rect = { x: toggleX, y: toggleY, width: toggleWidth, height: toggleHeight };
                    } else if (setting.type === 'slider') {
                        const sliderWidth = 200;
                        const sliderHeight = 10;
                        const sliderX = x + menuWidth - 240;
                        const sliderY = settingY + 15;
                        
                        const isHovered = this.isMouseInRect(sliderX, sliderY, sliderWidth, sliderHeight);
                        
                        // 绘制滑块背景
                        ctx.fillStyle = '#757575';
                        ctx.fillRect(sliderX, sliderY, sliderWidth, sliderHeight);
                        
                        // 绘制滑块填充
                        const fillWidth = sliderWidth * (setting.value / 100);
                        ctx.fillStyle = '#4caf50';
                        ctx.fillRect(sliderX, sliderY, fillWidth, sliderHeight);
                        
                        // 绘制滑块手柄
                        const handleX = sliderX + fillWidth - 10;
                        
                        ctx.fillStyle = '#fff';
                        ctx.fillRect(handleX, sliderY - 5, 20, 20);
                        
                        // 绘制值
                        ctx.fillStyle = '#fff';
                        ctx.font = '16px Arial';
                        ctx.textAlign = 'right';
                        ctx.fillText(setting.value, x + menuWidth - 40, settingY + 20);
                        
                        // 存储滑块信息用于点击检测
                        setting.rect = { x: sliderX, y: sliderY, width: sliderWidth, height: sliderHeight };
                    }
                });
                
                this.settingsMenu.settings = settings;
                
                // 绘制返回按钮
                const backButtonWidth = 150;
                const backButtonHeight = 40;
                const backButtonX = x + (menuWidth - backButtonWidth) / 2;
                const backButtonY = y + menuHeight - 60;
                const backHovered = this.isMouseInRect(
                    backButtonX, backButtonY, backButtonWidth, backButtonHeight
                );
                
                ctx.fillStyle = backHovered ? '#ff9800' : '#333';
                ctx.fillRect(backButtonX, backButtonY, backButtonWidth, backButtonHeight);
                
                ctx.strokeStyle = backHovered ? '#ffc107' : '#555';
                ctx.lineWidth = 2;
                ctx.strokeRect(backButtonX, backButtonY, backButtonWidth, backButtonHeight);
                
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 18px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('返回', backButtonX + backButtonWidth / 2, backButtonY + backButtonHeight / 2);
                
                this.settingsMenu.backButton = {
                    x: backButtonX,
                    y: backButtonY,
                    width: backButtonWidth,
                    height: backButtonHeight
                };
                
                ctx.restore();
            },
            handleClick: (x, y) => {
                if (!this.settingsMenu.visible) return;
                
                // 检查是否点击返回按钮
                const backButton = this.settingsMenu.backButton;
                if (backButton && this.isMouseInRect(
                    x, y, backButton.width, backButton.height, backButton.x, backButton.y
                )) {
                    this.hideMenu('settingsMenu');
                    return;
                }
                
                // 检查是否点击设置项
                if (this.settingsMenu.settings) {
                    for (const setting of this.settingsMenu.settings) {
                        if (setting.rect && this.isMouseInRect(
                            x, y, setting.rect.width, setting.rect.height, setting.rect.x, setting.rect.y
                        )) {
                            // 根据设置类型处理点击
                            if (setting.type === 'toggle') {
                                setting.value = !setting.value;
                            } else if (setting.type === 'slider') {
                                // 计算新值
                                const value = Math.max(0, Math.min(100, 
                                    ((x - setting.rect.x) / setting.rect.width) * 100
                                ));
                                setting.value = Math.round(value);
                            }
                            break;
                        }
                    }
                }
            }
        };
        
        this.uiElements.push(this.settingsMenu);
    }
    
    // 显示关于信息
    showAbout() {
        // 简单的关于提示
        alert('土豆兄弟 v1.0.0\n\n一个类似土豆兄弟的2D肉鸽游戏\n\n使用HTML5 Canvas开发\n\n© 2024');
    }
    
    // 更新UI
    update(deltaTime) {
        // 更新通知
        for (let i = this.notifications.length - 1; i >= 0; i--) {
            const notification = this.notifications[i];
            notification.update(deltaTime);
            
            if (notification.isExpired) {
                this.notifications.splice(i, 1);
            }
        }
        
        // 更新浮动文本
        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            const text = this.floatingTexts[i];
            text.update(deltaTime);
            
            if (text.isExpired) {
                this.floatingTexts.splice(i, 1);
            }
        }
        
        // 更新主动buff
        for (let i = this.activeBuffs.length - 1; i >= 0; i--) {
            const buff = this.activeBuffs[i];
            buff.update(deltaTime);
            
            if (buff.isExpired) {
                this.activeBuffs.splice(i, 1);
            }
        }
    }
    
    // 绘制UI
    draw(ctx) {
        // 绘制基础UI元素
        for (const element of this.uiElements) {
            if (element.type !== 'menu' || element.visible) {
                element.draw(ctx);
            }
        }
        
        // 绘制通知
        for (const notification of this.notifications) {
            notification.draw(ctx);
        }
        
        // 绘制浮动文本
        for (const text of this.floatingTexts) {
            text.draw(ctx);
        }
        
        // 绘制主动buff
        for (const buff of this.activeBuffs) {
            buff.draw(ctx);
        }
    }
    
    // 添加通知
    addNotification(message, duration = 3) {
        const notification = {
            message: message,
            duration: duration,
            timer: 0,
            isExpired: false,
            yOffset: -50,
            opacity: 0,
            fadeInTime: 0.5,
            fadeOutTime: 0.5,
            update: function(deltaTime) {
                this.timer += deltaTime;
                
                // 计算透明度
                if (this.timer < this.fadeInTime) {
                    this.opacity = this.timer / this.fadeInTime;
                } else if (this.timer > this.duration - this.fadeOutTime) {
                    this.opacity = (this.duration - this.timer) / this.fadeOutTime;
                } else {
                    this.opacity = 1;
                }
                
                // 计算Y偏移
                if (this.timer < this.fadeInTime) {
                    this.yOffset = -50 + 50 * (this.timer / this.fadeInTime);
                }
                
                // 检查是否过期
                if (this.timer >= this.duration) {
                    this.isExpired = true;
                }
            },
            draw: function(ctx) {
                const canvas = ctx.canvas;
                const width = 300;
                const height = 60;
                const x = (canvas.width - width) / 2;
                const y = canvas.height - 120 + this.yOffset;
                
                ctx.save();
                ctx.globalAlpha = this.opacity;
                
                // 绘制背景
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(x, y, width, height);
                
                // 绘制边框
                ctx.strokeStyle = '#ff9800';
                ctx.lineWidth = 2;
                ctx.strokeRect(x, y, width, height);
                
                // 绘制文本
                ctx.fillStyle = '#fff';
                ctx.font = '18px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(this.message, x + width / 2, y + height / 2);
                
                ctx.restore();
            }
        };
        
        this.notifications.push(notification);
    }
    
    // 添加浮动文本
    addFloatingText(x, y, text, color = '#fff', duration = 2) {
        const floatingText = {
            x: x,
            y: y,
            text: text,
            color: color,
            duration: duration,
            timer: 0,
            isExpired: false,
            yOffset: 0,
            opacity: 1,
            update: function(deltaTime) {
                this.timer += deltaTime;
                this.yOffset -= 100 * deltaTime;
                this.opacity = 1 - (this.timer / this.duration);
                
                if (this.timer >= this.duration) {
                    this.isExpired = true;
                }
            },
            draw: function(ctx) {
                ctx.save();
                ctx.globalAlpha = this.opacity;
                ctx.fillStyle = this.color;
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                
                // 添加文本阴影
                ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
                ctx.shadowBlur = 4;
                ctx.shadowOffsetX = 2;
                ctx.shadowOffsetY = 2;
                
                ctx.fillText(this.text, this.x, this.y + this.yOffset);
                ctx.restore();
            }
        };
        
        this.floatingTexts.push(floatingText);
    }
    
    // 添加主动buff
    addActiveBuff(type, duration, value, color) {
        const buff = {
            type: type,
            duration: duration,
            value: value,
            color: color,
            timer: 0,
            isExpired: false,
            update: function(deltaTime) {
                this.timer += deltaTime;
                if (this.timer >= this.duration) {
                    this.isExpired = true;
                }
            },
            draw: function(ctx) {
                const canvas = ctx.canvas;
                const buffSize = 40;
                const index = uiManager.activeBuffs.findIndex(b => b === this);
                const x = 20 + index * (buffSize + 10);
                const y = 60;
                
                ctx.save();
                
                // 绘制buff背景
                ctx.fillStyle = this.color;
                ctx.fillRect(x, y, buffSize, buffSize);
                
                // 绘制边框
                ctx.strokeStyle = '#fff';
                ctx.lineWidth = 2;
                ctx.strokeRect(x, y, buffSize, buffSize);
                
                // 绘制buff图标
                ctx.fillStyle = '#fff';
                ctx.font = '16px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                
                let icon = '?';
                switch (this.type) {
                    case 'damage': icon = '⚔️'; break;
                    case 'speed': icon = '💨'; break;
                    case 'luck': icon = '🍀'; break;
                    case 'defense': icon = '🛡️'; break;
                    case 'all': icon = '✨'; break;
                }
                
                ctx.fillText(icon, x + buffSize / 2, y + buffSize / 2 - 4);
                
                // 绘制剩余时间
                const timeLeft = Math.ceil(this.duration - this.timer);
                ctx.fillStyle = '#000';
                ctx.font = 'bold 10px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(timeLeft + 's', x + buffSize / 2, y + buffSize - 5);
                
                // 绘制持续时间条
                const timePercent = (this.duration - this.timer) / this.duration;
                const barHeight = 3;
                
                ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                ctx.fillRect(x, y + buffSize - barHeight, buffSize, barHeight);
                
                ctx.fillStyle = '#fff';
                ctx.fillRect(x, y + buffSize - barHeight, buffSize * timePercent, barHeight);
                
                ctx.restore();
            }
        };
        
        this.activeBuffs.push(buff);
    }
    
    // 显示菜单
    showMenu(menuName) {
        this.hideAllMenus();
        
        for (const element of this.uiElements) {
            if (element.type === 'menu' && element.name === menuName) {
                element.visible = true;
                this.activeMenu = element;
                
                // 特殊菜单初始化
                if (menuName === 'shopMenu') {
                    this.shopMenu.generateShopItems();
                } else if (menuName === 'upgradeMenu') {
                    this.upgradeMenu.generateUpgradeOptions();
                }
                
                break;
            }
        }
    }
    
    // 隐藏菜单
    hideMenu(menuName) {
        for (const element of this.uiElements) {
            if (element.type === 'menu' && element.name === menuName) {
                element.visible = false;
                this.activeMenu = null;
                break;
            }
        }
    }
    
    // 隐藏所有菜单
    hideAllMenus() {
        for (const element of this.uiElements) {
            if (element.type === 'menu') {
                element.visible = false;
            }
        }
        this.activeMenu = null;
    }
    
    // 显示结束菜单
    showEndMenu(isVictory, stats = {}) {
        this.endMenu.isVictory = isVictory;
        this.endMenu.stats = stats;
        this.showMenu('endMenu');
    }
    
    // 检查鼠标是否在矩形内
    isMouseInRect(x, y, width, height, rectX = 0, rectY = 0) {
        const mouseX = this.game.input.mouse.x;
        const mouseY = this.game.input.mouse.y;
        
        return mouseX >= rectX && 
               mouseX <= rectX + width && 
               mouseY >= rectY && 
               mouseY <= rectY + height;
    }
    
    // 处理鼠标点击
    handleMouseClick(x, y) {
        // 优先处理活动菜单的点击
        if (this.activeMenu && this.activeMenu.handleClick) {
            this.activeMenu.handleClick(x, y);
            return true;
        }
        
        return false;
    }
    
    // 切换UI可见性
    toggleUIElements(elements) {
        for (const key in elements) {
            if (this.hasOwnProperty(key)) {
                this[key] = elements[key];
            }
        }
    }
    
    // 获取UI状态
    getUIState() {
        return {
            showHealthBar: this.showHealthBar,
            showMoney: this.showMoney,
            showWaveInfo: this.showWaveInfo,
            showWeaponInfo: this.showWeaponInfo,
            showSkillInfo: this.showSkillInfo,
            activeMenu: this.activeMenu ? this.activeMenu.name : null
        };
    }
    
    // 设置UI状态
    setUIState(state) {
        for (const key in state) {
            if (this.hasOwnProperty(key)) {
                this[key] = state[key];
            }
        }
    }
    
    // 重置UI
    reset() {
        this.notifications = [];
        this.floatingTexts = [];
        this.activeBuffs = [];
        this.hideAllMenus();
    }
}

// 全局UI管理器实例
let uiManager = null;

// UI管理器函数
function getUIManager() {
    return uiManager;
}

function createUIManager(game) {
    uiManager = new UIManager(game);
    return uiManager;
}

function destroyUIManager() {
    uiManager = null;
}