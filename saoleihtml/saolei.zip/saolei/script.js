// 游戏配置
let gameConfig = {
    easy: { rows: 9, cols: 9, mines: 10 },
    medium: { rows: 16, cols: 16, mines: 40 },
    hard: { rows: 16, cols: 30, mines: 99 },
    custom: { rows: 10, cols: 10, mines: 10 }
};

// 游戏状态
let gameState = {
    board: [],
    rows: gameConfig.easy.rows,
    cols: gameConfig.easy.cols,
    mines: gameConfig.easy.mines,
    revealed: 0,
    flagged: 0,
    gameStarted: false,
    gameOver: false,
    won: false,
    firstClick: true,
    timer: null,
    time: 0
};

// DOM 元素
const boardElement = document.getElementById('game-board');
const mineCounterElement = document.getElementById('mine-counter');
const timeCounterElement = document.getElementById('time-counter');
const gameMessageElement = document.getElementById('game-message');
const restartButton = document.getElementById('restart');
const difficultyButtons = {
    easy: document.getElementById('easy'),
    medium: document.getElementById('medium'),
    hard: document.getElementById('hard'),
    custom: document.getElementById('custom')
};
const customSettingsElement = document.querySelector('.custom-settings');
const applyCustomButton = document.getElementById('apply-custom');

// 初始化事件监听器
function initEventListeners() {
    // 难度选择按钮
    Object.keys(difficultyButtons).forEach(difficulty => {
        difficultyButtons[difficulty].addEventListener('click', () => {
            if (difficulty === 'custom') {
                customSettingsElement.style.display = 'block';
            } else {
                customSettingsElement.style.display = 'none';
                setDifficulty(difficulty);
            }
        });
    });
    
    // 应用自定义设置
    applyCustomButton.addEventListener('click', applyCustomSettings);
    
    // 重新开始按钮
    restartButton.addEventListener('click', startNewGame);
}

// 设置游戏难度
function setDifficulty(difficulty) {
    // 更新活动按钮样式
    Object.keys(difficultyButtons).forEach(d => {
        difficultyButtons[d].classList.remove('active');
    });
    difficultyButtons[difficulty].classList.add('active');
    
    // 应用难度配置
    const config = gameConfig[difficulty];
    gameState.rows = config.rows;
    gameState.cols = config.cols;
    gameState.mines = config.mines;
    
    // 开始新游戏
    startNewGame();
}

// 应用自定义设置
function applyCustomSettings() {
    const rows = parseInt(document.getElementById('custom-rows').value);
    const cols = parseInt(document.getElementById('custom-cols').value);
    const mines = parseInt(document.getElementById('custom-mines').value);
    
    // 验证输入
    const maxMines = Math.floor((rows * cols) * 0.3); // 最大地雷数为总格子的30%
    const validRows = Math.max(5, Math.min(25, rows));
    const validCols = Math.max(5, Math.min(40, cols));
    const validMines = Math.max(1, Math.min(maxMines, mines));
    
    // 更新输入值
    document.getElementById('custom-rows').value = validRows;
    document.getElementById('custom-cols').value = validCols;
    document.getElementById('custom-mines').value = validMines;
    
    // 应用设置
    gameConfig.custom.rows = validRows;
    gameConfig.custom.cols = validCols;
    gameConfig.custom.mines = validMines;
    
    // 开始新游戏
    setDifficulty('custom');
}

// 初始化游戏板
function initBoard() {
    // 创建二维数组
    gameState.board = [];
    for (let row = 0; row < gameState.rows; row++) {
        gameState.board[row] = [];
        for (let col = 0; col < gameState.cols; col++) {
            gameState.board[row][col] = {
                isMine: false,
                isRevealed: false,
                isFlagged: false,
                adjacentMines: 0
            };
        }
    }
    
    // 更新UI
    renderBoard();
    updateMineCounter();
}

// 渲染游戏板
function renderBoard() {
    boardElement.innerHTML = '';
    boardElement.style.gridTemplateColumns = `repeat(${gameState.cols}, 30px)`;
    
    for (let row = 0; row < gameState.rows; row++) {
        for (let col = 0; col < gameState.cols; col++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = row;
            cell.dataset.col = col;
            
            // 添加点击事件
            cell.addEventListener('click', () => handleCellClick(row, col));
            cell.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                handleRightClick(row, col);
            });
            
            // 添加Shift+左键点击事件（快速揭示）
            cell.addEventListener('click', (e) => {
                if (e.shiftKey) {
                    handleQuickReveal(row, col);
                }
            });
            
            boardElement.appendChild(cell);
        }
    }
}

// 放置地雷（确保第一次点击的格子和周围没有地雷）
function placeMines(firstRow, firstCol) {
    let minesPlaced = 0;
    
    while (minesPlaced < gameState.mines) {
        const row = Math.floor(Math.random() * gameState.rows);
        const col = Math.floor(Math.random() * gameState.cols);
        
        // 确保不是第一次点击的格子或其周围格子
        const isFirstClickArea = Math.abs(row - firstRow) <= 1 && Math.abs(col - firstCol) <= 1;
        
        if (!gameState.board[row][col].isMine && !isFirstClickArea) {
            gameState.board[row][col].isMine = true;
            minesPlaced++;
        }
    }
    
    // 计算相邻地雷数
    calculateAdjacentMines();
}

// 计算每个格子相邻的地雷数
function calculateAdjacentMines() {
    for (let row = 0; row < gameState.rows; row++) {
        for (let col = 0; col < gameState.cols; col++) {
            if (!gameState.board[row][col].isMine) {
                let count = 0;
                
                // 检查周围8个格子
                for (let dr = -1; dr <= 1; dr++) {
                    for (let dc = -1; dc <= 1; dc++) {
                        if (dr === 0 && dc === 0) continue;
                        
                        const newRow = row + dr;
                        const newCol = col + dc;
                        
                        if (isValidCell(newRow, newCol) && gameState.board[newRow][newCol].isMine) {
                            count++;
                        }
                    }
                }
                
                gameState.board[row][col].adjacentMines = count;
            }
        }
    }
}

// 开始游戏
function startGame(firstRow, firstCol) {
    gameState.gameStarted = true;
    gameState.firstClick = false;
    
    // 放置地雷
    placeMines(firstRow, firstCol);
    
    // 启动计时器
    startTimer();
}

// 启动计时器
function startTimer() {
    gameState.time = 0;
    updateTimeCounter();
    
    gameState.timer = setInterval(() => {
        gameState.time++;
        updateTimeCounter();
        
        // 最大计时999秒
        if (gameState.time >= 999) {
            clearInterval(gameState.timer);
        }
    }, 1000);
}

// 停止计时器
function stopTimer() {
    if (gameState.timer) {
        clearInterval(gameState.timer);
        gameState.timer = null;
    }
}

// 处理格子点击
function handleCellClick(row, col) {
    if (gameState.gameOver || gameState.board[row][col].isRevealed || gameState.board[row][col].isFlagged) {
        return;
    }
    
    // 第一次点击开始游戏
    if (gameState.firstClick) {
        startGame(row, col);
    }
    
    // 揭示格子
    revealCell(row, col);
    
    // 检查游戏是否胜利
    checkWinCondition();
}

// 处理右键点击（标记地雷）
function handleRightClick(row, col) {
    if (gameState.gameOver || gameState.board[row][col].isRevealed) {
        return;
    }
    
    // 第一次右键点击也开始游戏（但不揭示格子）
    if (gameState.firstClick) {
        startGame(row, col);
    }
    
    const cell = gameState.board[row][col];
    
    if (cell.isFlagged) {
        // 移除标记
        cell.isFlagged = false;
        gameState.flagged--;
    } else if (gameState.flagged < gameState.mines) {
        // 添加标记
        cell.isFlagged = true;
        gameState.flagged++;
    }
    
    // 更新UI
    updateCellUI(row, col);
    updateMineCounter();
    checkWinCondition();
}

// 处理快速揭示（Shift+左键）
function handleQuickReveal(row, col) {
    if (!gameState.gameStarted || gameState.gameOver || !gameState.board[row][col].isRevealed) {
        return;
    }
    
    // 计算周围的标记数
    let flaggedCount = 0;
    const adjacentCells = [];
    
    for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            
            const newRow = row + dr;
            const newCol = col + dc;
            
            if (isValidCell(newRow, newCol)) {
                if (gameState.board[newRow][newCol].isFlagged) {
                    flaggedCount++;
                } else if (!gameState.board[newRow][newCol].isRevealed) {
                    adjacentCells.push({ row: newRow, col: newCol });
                }
            }
        }
    }
    
    // 如果标记数等于相邻地雷数，则揭示周围未标记的格子
    if (flaggedCount === gameState.board[row][col].adjacentMines) {
        for (const cell of adjacentCells) {
            revealCell(cell.row, cell.col);
            // 如果揭示到地雷，游戏结束
            if (gameState.gameOver) break;
        }
    }
    
    // 检查游戏是否胜利
    checkWinCondition();
}

// 揭示格子
function revealCell(row, col) {
    const cell = gameState.board[row][col];
    
    if (cell.isRevealed || cell.isFlagged) return;
    
    cell.isRevealed = true;
    gameState.revealed++;
    
    // 更新UI
    updateCellUI(row, col);
    
    // 如果是地雷，游戏结束
    if (cell.isMine) {
        gameOver(false);
        return;
    }
    
    // 如果是空白格子（周围没有地雷），递归揭示周围格子
    if (cell.adjacentMines === 0) {
        for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
                if (dr === 0 && dc === 0) continue;
                
                const newRow = row + dr;
                const newCol = col + dc;
                
                if (isValidCell(newRow, newCol)) {
                    revealCell(newRow, newCol);
                }
            }
        }
    }
}

// 游戏结束
function gameOver(won) {
    gameState.gameOver = true;
    gameState.won = won;
    stopTimer();
    
    // 显示所有地雷
    for (let row = 0; row < gameState.rows; row++) {
        for (let col = 0; col < gameState.cols; col++) {
            const cell = gameState.board[row][col];
            
            if (cell.isMine) {
                cell.isRevealed = true;
                updateCellUI(row, col, won);
            } else if (cell.isFlagged) {
                // 显示错误标记
                updateCellUI(row, col, won);
            }
        }
    }
    
    // 显示游戏消息
    showGameMessage(won);
}

// 检查胜利条件
function checkWinCondition() {
    // 所有非地雷格子都被揭示
    const totalCells = gameState.rows * gameState.cols;
    const safeCells = totalCells - gameState.mines;
    
    if (gameState.revealed === safeCells) {
        gameOver(true);
        return;
    }
    
    // 或者所有地雷都被正确标记
    let correctlyFlagged = 0;
    for (let row = 0; row < gameState.rows; row++) {
        for (let col = 0; col < gameState.cols; col++) {
            const cell = gameState.board[row][col];
            if (cell.isMine && cell.isFlagged) {
                correctlyFlagged++;
            }
        }
    }
    
    if (correctlyFlagged === gameState.mines) {
        // 自动揭示所有剩余格子
        for (let row = 0; row < gameState.rows; row++) {
            for (let col = 0; col < gameState.cols; col++) {
                const cell = gameState.board[row][col];
                if (!cell.isMine && !cell.isRevealed) {
                    cell.isRevealed = true;
                    gameState.revealed++;
                    updateCellUI(row, col);
                }
            }
        }
        gameOver(true);
    }
}

// 更新格子UI
function updateCellUI(row, col, gameWon) {
    const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
    const cell = gameState.board[row][col];
    
    // 重置样式
    cellElement.className = 'cell';
    cellElement.textContent = '';
    
    if (cell.isRevealed) {
        cellElement.classList.add('revealed');
        
        if (cell.isMine) {
            cellElement.classList.add('mine');
            cellElement.textContent = '💣';
            
            // 如果是引爆的地雷
            if (!gameWon) {
                cellElement.classList.add('exploded');
            }
        } else if (cell.adjacentMines > 0) {
            cellElement.classList.add(`number-${cell.adjacentMines}`);
            cellElement.textContent = cell.adjacentMines;
        }
    } else if (cell.isFlagged) {
        cellElement.classList.add('flagged');
        cellElement.textContent = '🚩';
        
        // 如果游戏失败，显示错误的标记
        if (gameWon === false && !cell.isMine) {
            cellElement.textContent = '❌';
        }
    }
}

// 更新地雷计数器
function updateMineCounter() {
    const remainingMines = gameState.mines - gameState.flagged;
    mineCounterElement.textContent = Math.max(0, remainingMines);
}

// 更新计时器
function updateTimeCounter() {
    timeCounterElement.textContent = gameState.time;
}

// 显示游戏消息
function showGameMessage(won) {
    gameMessageElement.className = 'game-message';
    
    if (won) {
        gameMessageElement.classList.add('win', 'win-animation');
        gameMessageElement.textContent = `恭喜你赢了！用时 ${gameState.time} 秒`;
    } else {
        gameMessageElement.classList.add('lose');
        gameMessageElement.textContent = '游戏结束！踩到地雷了';
    }
}

// 开始新游戏
function startNewGame() {
    // 重置游戏状态
    gameState.revealed = 0;
    gameState.flagged = 0;
    gameState.gameStarted = false;
    gameState.gameOver = false;
    gameState.won = false;
    gameState.firstClick = true;
    gameState.time = 0;
    
    // 停止计时器
    stopTimer();
    
    // 清空游戏消息
    gameMessageElement.className = 'game-message';
    gameMessageElement.textContent = '';
    
    // 初始化游戏板
    initBoard();
}

// 检查格子是否有效
function isValidCell(row, col) {
    return row >= 0 && row < gameState.rows && col >= 0 && col < gameState.cols;
}

// 初始化游戏
function initGame() {
    initEventListeners();
    startNewGame();
}

// 页面加载完成后初始化游戏
window.addEventListener('DOMContentLoaded', initGame);